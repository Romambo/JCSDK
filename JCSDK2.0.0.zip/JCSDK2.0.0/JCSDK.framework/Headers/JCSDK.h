//
//  JCSDK.h
//  JCSDK
//
//  Created by MS on 2020/8/11.
//  Copyright © 2020 wangyibo. All rights reserved.
//
// version:2.0.1
// 优化了kochava归因逻辑
// 优化了unity初始化超时回调时间2s
// 优化了rv和inter混合使用时加载错误的bug

#import <Foundation/Foundation.h>
#import "JC_iOSAdApi.h"
#import "JCAdCallBackHeader.h"
#import "JCNativeView.h"
#import "JCNativeConfig.h"
#import "JC_unityAdApi.h"
#import "JC_unityCallBackApi.h"
//! Project version number for JCSDK.
FOUNDATION_EXPORT double JCSDKVersionNumber;

//! Project version string for JCSDK.
FOUNDATION_EXPORT const unsigned char JCSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JCSDK/PublicHeader.h>


